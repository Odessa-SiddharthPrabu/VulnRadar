---
name: vulnradar
description: Use when scanning LessorPortal or the Odessa framework for vulnerabilities, checking whether a rule or advisory applies to code, triaging a CVE/advisory or VAPT finding, proposing a security fix with tests, or refreshing the VulnRadar dashboard.
---

# VulnRadar

VulnRadar compares the Odessa code (Lw.* base layer and project layer) against three sources:

- the VAPT and pentest findings the organisation has logged in Jira;
- public vulnerability advisories for the components the code uses;
- the global weakness lists: OWASP Top 10:2025 and MITRE CWE Top 25.

The goal is to surface issues before the vendor VAPT, including classes the vendor has not reported yet and new advisories no Jira ticket names. Only real findings go into `findings.json` and the dashboard, each tied to a file and line or to a component version.

The dashboard is a SonarQube-style report:

- every issue is located on a line;
- every issue carries its own message, why it is an issue, why it is reported here, and how to fix it.

The vendor-led VAPT stays in place as the safety net.

## Prompt parameters

The user sends a block like this; lines left out take the default. `README.md` in the VulnRadar folder has more examples for every mode.

```yaml
/vulnradar
repo:        D:\DefectInt\Odessa.Framework   # repo root on the linked laptop
scope:                                        # files or folders relative to repo, or "all"
  - Lw.WebPortal\Controllers\ProxyController.cs
mode:        scan       # scan | check-rule | check-advisory <id> | explain VR-0NN | fix VR-0NN | close VR-0NN | refresh | list-rules
rules:                  # check-rule only: rule keys, e.g. VR-RULE-CSRF
record:      no         # check-rule only: yes = add the results to the report
jira:        default    # default | JQL
feeds:       all        # all | npm only | none
inventory:   default    # default | extra .csproj / package-lock.json / Scripts folders
severity:    all        # all | Critical | High | Medium | Low
tokenLimit:  50%
output:      D:\VulnRadar   # the VulnRadar folder (project home)
fresh:       no         # yes = start a new report
```

| Parameter | Default if omitted |
|---|---|
| repo | Ask |
| scope | Ask (not needed for `explain`, `refresh`, `list-rules`, `check-advisory`) |
| mode | `scan` |
| rules | Ask when mode is `check-rule` |
| record | `no` |
| jira | The default JQL in Stage 1 |
| feeds | `all` |
| inventory | `Lw.WebPortal/Lw.WebPortal.csproj`, root `package-lock.json`, `Lw.WebPortal/Scripts` |
| severity | All |
| tokenLimit | 50% of the session token budget |
| output | `D:\VulnRadar`; if that folder does not exist on this laptop, ask where the VulnRadar folder is |
| fresh | `no` |

## Project home

The VulnRadar folder named by `output` (default `D:\VulnRadar`) holds every project file. Every run updates these files in place; never create a second copy elsewhere.

1. **Connect the folder.** If it is not connected, request it with `device_request_folder_access`.
2. **Copy the files in.** At the start of every run, copy all project files into a workspace folder with `device_stage_files` and record each file's `mtimeMs`. The workspace is not kept between sessions, and the user may have edited `triage.json`.
3. **Write the files back.**
   - Deliver each changed file with `SendUserFile` first.
   - Then write it with `device_commit_files` using the returned `fileUuid` and `expectedMtimeMs`, so a newer edit by the user is never overwritten.
   - If a write is refused, re-stage that file, merge, and try again.
4. **Verify the write.**
   - Re-stage every written file and compare it byte for byte with the workspace version.
   - If any differ, write them again and say so in the summary.
   - Never report a file as saved without this check.
5. **Leave other files alone.** Files in the folder that are not project files are not touched. Mention them once.

Project files:

- `README.md`
- `skill/SKILL.md`
- `vulnradar-skill.zip`
- `vulnradar-dashboard.html`
- `vulnradar_scan.py`
- `vulnradar_feeds.py`
- `vulnradar_rules.json`
- `build_dashboard.py`
- `triage.json`
- `findings.json`
- `feeds.json`
- `jira_vapt.json`
- `scripts_listing.txt`

If a project file is missing, tell the user which one.

## Rules that always apply

- **Real data only.**
  - Never write sample, example or estimated findings.
  - Every code finding needs a file, line numbers, a specific message per line and a verdict.
  - Every dependency finding needs the component, its version, the declaring line and advisory IDs returned by a database.
  - Every Jira key must come from a Jira read.
- **No invented scores.** Never write a CVE or GHSA ID or a CVSS score from memory. Leave `cvss` null unless an advisory supplies it.
- **Explain every issue.** Every rule that can raise an issue, including AI-review rules, needs an entry in `vulnradar_rules.json` before it is reported:
  - name, type and default severity;
  - why it is an issue and how to fix it;
  - noncompliant and compliant examples;
  - references (CWE, OWASP cheat sheet).
- **Add to the report, don't replace it.**
  - Without `fresh: yes`, the scanner keeps earlier files' findings, IDs, source and rule hits, and re-checks only the files in this run's scope.
  - Never pass `--fresh` to the main report unless the user asked.
- **Token budget.**
  - At the start, and after each stage, report tokens used and tokens left from the `total_tokens` budget.
  - Stop and report when `tokenLimit` is reached.
  - Before rebuilding, add this run's usage to `run.usedTotal` in `triage.json`.
- **Scope.**
  - Scan only the scope the user gave. Copying from the laptop is 50 files per call.
  - Do not launch background copy agents without the user's agreement.
  - Do not scan files outside the scope, even if they are already in the workspace.
- **Blocked sources.** If a source is blocked (proxy refusal, web search disabled), do not use mirrors or other hosts of the same data. Tell the user which domains an admin must allow.
- **Secrets.**
  - The scanner masks passwords in the embedded source as `********`.
  - Before delivering, check `sources_code` for other secrets (keys, tokens, connection strings) and extend the `SECRET` patterns if one appears.
  - Assembly `publicKeyToken` values are public identifiers, not secrets.

## Modes

| Mode | What to do |
|---|---|
| `scan` | Stages 0, 1, 2, 3, 4, 5. |
| `check-rule` | Stage 0, Stage 2 for the scope, then Stage 4 in check mode (below). With `record: yes`, run a normal `scan` of the same scope afterwards. |
| `check-advisory <id>` | Stage 0, then Stage 3. Say whether any component version in the inventory falls in the advisory's affected range, where it is declared, and how it is used. If it applies, add the finding (Stage 4) and rebuild (Stage 5). |
| `explain VR-0NN` | Stage 0 only. Answer from `findings.json`: locations, message, why it is an issue, why it is reported here, how to fix it, and the Jira and advisory references. No scan, no writes. |
| `fix VR-0NN` | Stage 0, Fix, then Stage 5. |
| `close VR-0NN` | Stage 0, Validate and close, then Stage 5. |
| `refresh` | Stage 0, then Stage 5 (rebuild after `triage.json` was edited). |
| `list-rules` | Stage 0 only. List the rules in `vulnradar_rules.json` with key, name, type, severity and origin. |
| A new VAPT or Burp finding | Stage 0, Stage 1, then add or update its rule and catalog entry, then Stages 4 and 5. |

### Check mode (`check-rule`)

1. Run the scanner with only the requested rules, into a separate file, so the main report is not touched:
   ```
   python vulnradar_scan.py --root <repo> --files <scope> --jira jira_vapt.json --feeds feeds.json --triage triage.json --only-rules <KEY1,KEY2> --fresh --out check.json
   ```
2. Read the matched lines and their surrounding code yourself, and decide per hit: Verified, Needs investigation or Not applicable.
3. For an AI-review rule (a rule with no automated pattern), read the scoped files and apply the rule's description from `vulnradar_rules.json` by hand.
4. Answer in chat:
   - whether the rule applies, with file, line, the code and the reason;
   - for files where it does not apply, say so per file.
5. Do not write any project file unless `record: yes`.

## Stage 0: Load the project

Copy the project files from the VulnRadar folder into a workspace folder and run every script from there (see "Project home").

## Stage 1: Pull VAPT history from Jira

Skip this stage if `jira_vapt.json` was refreshed today.

1. Use the Atlassian connector. The cloud id comes from `getAccessibleAtlassianResources` (site `odessainc.atlassian.net`).
2. Run `searchJiraIssuesUsingJql` with:
   - JQL: `(summary ~ "VAPT" OR description ~ "VAPT" OR summary ~ "PENTEST" OR labels in (VAPT, vapt, Security, security, pentest, PenTest, PENTEST)) ORDER BY created DESC`, or the user's filter;
   - `maxResults` 100; page with `nextPageToken` until `hasNextPage` is false;
   - fields: summary, status, issuetype, priority, labels, components, created, resolution, project.
3. Large pages are saved to files. Parse them with Python, de-duplicate by key and write `jira_vapt.json`.

The scanner drops infrastructure tickets (WAF reviews, servers, deployments, environment setup) and groups the rest into vulnerability classes mapped to OWASP Top 10:2025.

## Stage 2: Copy the code and inventory files in scope

- Files on the laptop: `device_stage_files` (max 50 paths per call) copies them to `/mnt/user-data/uploads/<repo>/...`.
- For a folder scope, list it with `device_list_dir` first and copy the `.cs`, `.cshtml` and `.config` files.
- Also copy the inventory files:
  - the `.csproj`;
  - the `package-lock.json`;
  - the vendor JS files whose version is only in the header (e.g. `underscore.js`, `js.cookie.js`, `jquery.jqGrid.src.js`).
- Refresh `scripts_listing.txt` from a `device_list_dir` of the `Scripts` folder.
- Never copy `bin`, `obj`, `node_modules`, `.git` or generated `Core.Base.*` files.
- In a local or CI checkout, run the scripts there directly.

## Stage 3: Global feeds

```
python vulnradar_feeds.py --root <repo> --csproj <proj...> --lock package-lock.json --scripts-dir <Scripts> [--scripts-list scripts_listing.txt] --out feeds.json
```

Sources:

- **GitHub Advisory Database** via the npm audit bulk endpoint (`registry.npmjs.org`, allowed by default). It covers npm packages and the JavaScript shipped in NuGet packages (jQuery, bootstrap, jQuery.Validation).
- **OSV.dev** (`api.osv.dev`): NuGet and npm.
- **NuGet vulnerability resource** (`api.nuget.org`), **CISA KEV** (`www.cisa.gov`) and **NIST NVD** (`services.nvd.nist.gov`): reachability is checked; data pulls are not implemented yet.

Notes:

- Libraries with no ecosystem package (e.g. Trirand jqGrid, jQuery blockUI) are listed as not checked.
- An assembly version in a `bindingRedirect` is not the package version.
- Run `vulnradar_feeds.py` on the laptop itself when the session's network blocks a source; it then uses the laptop's network.

## Stage 4: Scan and triage

1. Run:
   ```
   python vulnradar_scan.py --root <repo> --files <relative paths...> --jira jira_vapt.json --feeds feeds.json --triage triage.json --out findings.json
   ```
   - The run adds to the existing `findings.json`.
   - Omit `--files` to scan every `.cs`, `.cshtml` and `.config` file under the root.
   - `--rules` defaults to `vulnradar_rules.json` next to the script.
2. Read every file in scope yourself. The rules catch patterns; you catch logic (e.g. an authentication context read from a cookie, a reset flow that answers differently for existing accounts, raw SQL taken from the request).
   - Give each such issue its own rule key, add it to `RULES` in the scanner and to `vulnradar_rules.json`.
   - Add it to `triage.json` under `manual`: fp, rule, file, line, `detail` (the line-specific message), title, `cwe` (a list), owasp and vaptClass.
   - Several lines with one root cause become several manual entries grouped with `group`.
3. Write each location's message as an instruction about that line.
   - Example: "[HttpPost] ResetPassword() has no [ValidateAntiForgeryToken]; add it, or confirm a global anti-forgery filter covers this action."
   - Keep the message's first word stable: the fingerprint for code rules is derived from it.
4. Add a `triage.json` entry for each new fingerprint, including dependency findings:
   - `id`, `title`, `severity`, `stage` (`Assessed`), `verdict`, `status`;
   - `notes`: why it is reported for this code, with the lines;
   - `jiraRefs`: the most relevant Jira keys, open ones first;
   - `group`: to merge hits that share one root cause.
   - Leave existing entries unchanged unless the code changed.
5. For dependency findings, check reachability: how the library is called, and whether it ships to browsers or is build-time only.
6. Verdicts:
   - **Verified → Vulnerability:** the code, config or version shown proves the issue.
   - **Needs investigation → Security Hotspot:** it depends on code outside the scope. Say exactly what to check.
   - **Not applicable → Ruled out:** a rule hit that does not hold. Give the reason.
7. Severity:
   - With an advisory CVSS: Critical 9.0+, High 7.0–8.9, Medium 4.0–6.9, Low below 4.0. Adjust for reachability.
   - Otherwise, judge from impact and reachability.
8. When rescanning a file after a fix, list the findings that no longer appear as "resolved by rescan" in the summary. Close them in `triage.json` only after the user confirms the fix was approved.

Rules (full descriptions in `vulnradar_rules.json`; `list-rules` shows them all):

| Rule | Checks for |
|---|---|
| VR-RULE-GET-STATE | Actions with no HTTP verb attribute that may change state |
| VR-RULE-CSRF | `[HttpPost]` without `[ValidateAntiForgeryToken]` |
| VR-RULE-PRELOGIN-LOOKUP, VR-RULE-RESET-ENUM | User enumeration before login and in password reset |
| VR-RULE-COOKIE-AUTHCTX | Authentication context deserialised from a cookie |
| VR-RULE-CUSTOMERRORS-OFF, VR-RULE-DEBUG-TRUE, VR-RULE-ELMAH-REMOTE, VR-RULE-EXCEPTION-MESSAGE | Information disclosure |
| VR-RULE-NO-HSTS, VR-RULE-NO-CSP | Security headers |
| VR-RULE-COOKIE-SECURE, VR-RULE-SESSION-TIMEOUT | Cookie and session settings |
| VR-RULE-PLAINTEXT-PASSWORD, VR-RULE-SECRET-DISCLOSURE, VR-RULE-HARDCODED-SECRET | Credentials in config, code or responses |
| VR-RULE-REQUEST-LIMIT, VR-RULE-HTTP-ENDPOINT | Upload limits, plain HTTP |
| VR-RULE-SQL-CONCAT, VR-RULE-REQUEST-SQL, VR-RULE-HTML-RAW, VR-RULE-OPEN-REDIRECT, VR-RULE-PROCESS-START | Injection |
| VR-RULE-PATH-TRAVERSAL, VR-RULE-SSRF, VR-RULE-OPEN-PROXY, VR-RULE-ALLOW-ANONYMOUS, VR-RULE-TEST-ENDPOINT, VR-RULE-PUBLIC-NONACTION | Access control (incl. public helpers on base controllers exposed as actions) |
| VR-RULE-OTP-BRUTEFORCE, VR-RULE-OTP-DESTINATION | MFA |
| VR-RULE-SECURITY-EVENT-LOG | Logging and alerting |
| VR-RULE-UNSAFE-DESERIALIZE, VR-RULE-WEAK-CRYPTO, VR-RULE-CERT-BYPASS | Deserialisation and cryptography |
| VR-DEP | Component version inside an advisory's affected range |

When a new VAPT class appears in Jira or a global class needs coverage:

- add the rule to `RULES` (CWE list, OWASP 2025 code);
- add it to `scan_cs`, `scan_config` or `LINE_RULES` with a line-specific message;
- add its catalog entry;
- add a pattern to `CLASSES`.

Use the `odessa-ast-grep` skill for structural C# patterns.

## Stage 5: Rebuild and deliver

1. Update `run` in `triage.json`. Re-run the scan if triage changed, then run `python build_dashboard.py findings.json vulnradar-dashboard.html`.
2. Open the report once and check:
   - issue lines in the Code tab point at the right source lines;
   - every triggered rule shows a description.
3. Write every changed project file back and verify it (see "Project home").
4. Summarise:
   - this run's scope and the report's total scope;
   - new findings by type (vulnerabilities, hotspots, ruled out);
   - the highest-risk findings;
   - findings resolved by rescan;
   - new advisory findings;
   - blocked sources;
   - tokens used and left.

The report has five tabs:

- **Overview:** rating A–E, metrics, files, run details and tokens.
- **Issues:** per-line issues with facets and full explanations.
- **Code:** files with inline issues.
- **Rules:** the catalog.
- **Security posture:** OWASP and CWE coverage, Jira classes, components.

## Fix (only when asked)

- Make the smallest correct change in the right layer. A base-layer change reaches every portal, so say so.
- Add tests:
  - MSTest + NSubstitute unit tests where logic changed;
  - a Playwright regression test for anything reachable over HTTP (e.g. "GET to the action returns 405").
- For a dependency, upgrade to the first patched version in the advisory and re-run Stages 3 to 5.
- Follow the repo's CLAUDE.md quality gate (Sigrid and OCA review).
- Ask before creating Jira tickets, branches, commits, pushes or PRs. Never merge.

## Validate and close

- Confirm the build and tests pass and a rescan no longer matches.
- Close a finding only after a person has approved the PR: set `stage` and `status` to Closed and the `closed` date in `triage.json`, then rebuild.

## Guardrails

- Strip session tokens, cookies, passwords and connection strings from logs, config, evidence and embedded source before quoting or writing them.
- The report contains source code and open vulnerability locations: share it only inside the development and security team.
- Send code only to approved endpoints. Never close a finding, merge a PR or change a ticket's status without the user's approval.
- This tool finds known patterns, logged VAPT classes and published advisories. It does not replace the vendor VAPT for business-logic flaws.
